to get this lib I run:
npm install monaco
and copied node_modules/monaco-editor